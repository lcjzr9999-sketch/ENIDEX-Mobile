# ENIDEX Mobile — Read-only Order Book Prototype

This is the first native Android prototype for read-only ENI/USDT order-book inspection.

## Build
- JDK 17
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- Android SDK 35

Run:

```bash
gradle assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Current scope
- POST GraphQL requests to `https://graph.eni.top/subgraphs/name/orderbook-dex`
- Poll every 10 seconds
- Display raw order fields without assuming decimal precision or buy/sell mapping
- No wallet connection, private keys, approvals, or trading

## Important validation note
The `pair: "ENI_USDT"` GraphQL filter is isolated in `MainActivity.java`. It must be checked against the complete browser-captured GraphQL query. If the subgraph schema uses a different pair filter field, the app displays the GraphQL error rather than inventing data.
