package com.enidex.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final String ENDPOINT =
            "https://graph.eni.top/subgraphs/name/orderbook-dex";

    // Pair filter is intentionally isolated here so it can be adjusted
    // against the exact browser-captured GraphQL payload if the schema differs.
    private static final String GRAPHQL_QUERY =
            "query Depth { orders(skip: 0, first: 100, orderBy: price, " +
            "orderDirection: asc, where: { pair: \\"ENI_USDT\\" }) " +
            "{ id orderType price remainingIn remainingOut timestamp } }";

    private TextView statusView;
    private TextView dataView;
    private Button refreshButton;
    private ScheduledExecutorService executor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        executor = Executors.newSingleThreadScheduledExecutor();
        refreshNow();
        executor.scheduleWithFixedDelay(this::loadOrders, 10, 10, TimeUnit.SECONDS);
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(12, 18, 30));
        root.setPadding(dp(18), dp(20), dp(18), dp(16));

        TextView title = new TextView(this);
        title.setText("ENIDEX");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView pair = new TextView(this);
        pair.setText("ENI / USDT  ·  只读行情");
        pair.setTextColor(Color.rgb(34, 211, 164));
        pair.setTextSize(18);
        pair.setPadding(0, dp(5), 0, dp(12));
        root.addView(pair);

        statusView = new TextView(this);
        statusView.setText("正在连接订单簿接口…");
        statusView.setTextColor(Color.LTGRAY);
        statusView.setTextSize(13);
        root.addView(statusView);

        refreshButton = new Button(this);
        refreshButton.setText("立即刷新");
        refreshButton.setOnClickListener(v -> refreshNow());
        root.addView(refreshButton);

        TextView disclaimer = new TextView(this);
        disclaimer.setText("原始订单簿数据验证版。价格、数量精度及买卖方向尚未核验，暂不进行换算或下单。");
        disclaimer.setTextColor(Color.rgb(255, 195, 90));
        disclaimer.setTextSize(12);
        disclaimer.setPadding(0, dp(10), 0, dp(12));
        root.addView(disclaimer);

        ScrollView scroll = new ScrollView(this);
        dataView = new TextView(this);
        dataView.setTextColor(Color.rgb(225, 232, 242));
        dataView.setTextSize(13);
        dataView.setTypeface(Typeface.MONOSPACE);
        dataView.setText("等待首次数据…");
        scroll.addView(dataView);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);
    }

    private void refreshNow() {
        if (refreshButton != null) refreshButton.setEnabled(false);
        statusView.setText("正在请求 ENI_USDT 订单簿…");
        if (executor != null) executor.execute(this::loadOrders);
    }

    private void loadOrders() {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(ENDPOINT);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(12000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");

            JSONObject body = new JSONObject();
            body.put("query", GRAPHQL_QUERY);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(bytes);
            }

            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 400
                    ? connection.getInputStream() : connection.getErrorStream();
            String response = readAll(stream);

            if (code < 200 || code >= 300) {
                publish("HTTP " + code, "接口返回 HTTP " + code + "\n\n" + response);
                return;
            }

            JSONObject json = new JSONObject(response);
            JSONArray errors = json.optJSONArray("errors");
            if (errors != null && errors.length() > 0) {
                publish("GraphQL 查询错误", "服务器已响应，但查询条件或字段不匹配：\n\n" +
                        errors.toString(2));
                return;
            }

            JSONObject data = json.optJSONObject("data");
            JSONArray orders = data == null ? null : data.optJSONArray("orders");
            if (orders == null) {
                publish("响应格式待检查", response);
                return;
            }

            StringBuilder output = new StringBuilder();
            output.append("接口：").append(ENDPOINT).append("\n");
            output.append("交易对筛选：ENI_USDT\n");
            output.append("订单数量：").append(orders.length()).append("\n");
            output.append("更新时间：").append(java.text.DateFormat
                    .getDateTimeInstance().format(new java.util.Date())).append("\n\n");

            for (int i = 0; i < orders.length(); i++) {
                JSONObject order = orders.optJSONObject(i);
                if (order == null) continue;
                output.append("订单 #").append(i + 1).append("\n");
                output.append("方向原始值 orderType：")
                        .append(order.optString("orderType", "—")).append("\n");
                output.append("价格原始值：")
                        .append(order.optString("price", "—")).append("\n");
                output.append("remainingIn：")
                        .append(order.optString("remainingIn", "—")).append("\n");
                output.append("remainingOut：")
                        .append(order.optString("remainingOut", "—")).append("\n");
                output.append("时间戳：")
                        .append(order.optString("timestamp", "—")).append("\n");
                output.append("ID：")
                        .append(order.optString("id", "—")).append("\n");
                output.append("--------------------------------\n");
            }

            publish("连接成功 · 收到 " + orders.length() + " 条订单", output.toString());
        } catch (Exception e) {
            publish("连接失败", e.getClass().getSimpleName() + ": " +
                    (e.getMessage() == null ? "未知错误" : e.getMessage()) +
                    "\n\n请检查网络，或核对 GraphQL 的 pair 筛选字段。");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line).append('\n');
        }
        return result.toString();
    }

    private void publish(String status, String content) {
        runOnUiThread(() -> {
            statusView.setText(status);
            dataView.setText(content);
            refreshButton.setEnabled(true);
        });
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onDestroy() {
        if (executor != null) executor.shutdownNow();
        super.onDestroy();
    }
}
