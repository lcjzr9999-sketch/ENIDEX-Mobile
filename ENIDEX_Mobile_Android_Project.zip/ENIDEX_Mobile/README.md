# ENIDEX Mobile (Android project)

Android WebView dashboard for ENIDEX ecosystem markets. It is read-only and does not request wallet secrets or sign transactions.

## Verified official network / market facts
- ENI V0.2 mainnet: Chain ID `263`
- RPC: `https://rpc.eni.top`
- Explorer: `https://scan.eni.top`
- DEX: `https://enidex.eni.top/`
- Official announcements confirm ENIDEX uses an order book, exposes market depth, and provides verifiable on-chain trade records.
- Official ENI announcement links an `EVBC_USDT` pair.

## Live market API status
No public, independently verifiable ENIDEX REST or WebSocket market-data specification has been located. The standalone price/K-line/depth/trades panels therefore remain blank rather than showing fabricated data. The app provides direct in-app access to the official ENIDEX market page for live market viewing.

Do not infer an API from another exchange, and do not add ecosystem tokens by ticker alone. Confirm each token contract address and the corresponding ENIDEX pair first.

## Build locally or in CI
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17 or newer
- Android SDK Platform: 35

Run `gradle assembleDebug` in an Android SDK environment. A GitHub Actions workflow is included at `.github/workflows/android.yml` to build a debug APK when this project is pushed to GitHub.

## Current verification
- HTML structure / JavaScript syntax / required official links: static checks pass.
- APK compilation and device installation: not run in this environment because Android SDK and Gradle are unavailable.
